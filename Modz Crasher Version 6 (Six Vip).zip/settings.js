const chalk = require("chalk")
const fs = require("fs")

//============= SETTING BOT =============//
global.owner = ['6285123965378'] //ur owner number
global.ownernomer = "6285123965378" //ur owner number2
global.ownerNumber = ["6285123965378@s.whatsapp.net"]

global.version = "6.0.0" //ur owner name
global.ownername = "ʀᴀғʟɪᴇ ᴅᴇᴠᴇʟᴏᴘᴇʀ" //ur owner name
global.ytname = "Raflie Modz" //ur yt chanel name
global.saluran = "https://whatsapp.com/channel/0029Vb4JgBC6LwHq91Xxrn3O" //ur channel whatsapp link
global.socialm = "-" //ur github or insta name
global.location = "Arab Saudi" //ur location
global.thumurl = '_'

//SETTINGS DB
global.tokendb = "_"

//PAYMENT
global.dana = "085754661077" //PAYMENT DANA
global.ovo = "BELUM ADA" //PAYMENT OVO
global.gopay = "BELUM ADA" //PAYMENT GOPAY
global.qris = "https://files.catbox.moe/2b7iln.jpg" //PAYMENT QRIS

//new
global.ownergc = "𝐑͜𝐚⃔𝐟𝐥́𝐢͢͢͢͠𝐞 𝐌͢𝐨͠𝐝𝐳"
global.botname = "𝐌͠𝐨͢͠𝐝͠𝐳 𝐂͠𝐫𝐚͢͠𝐬͠𝐡𝐞͠𝐫"
global.chid = "120363400270911185@newsletter"
global.sch = "https://whatsapp.com/channel/0029Vb5S13v11ulVlkNPNY1e"
global.ownerNumber = ["6285123965378@s.whatsapp.net"]
global.ownerweb = "https://youtube.com/"
global.themeemoji = '🪀'
global.wm = "〒𝙸𝚣𝚞𝚖𝚒 𝚁𝚊𝚏𝚕𝚒𝚎 𝙼𝚘𝚍𝚣"
global.packname = "raflieaja"
global.author = "ʀᴀғʟɪᴇ ᴅᴇᴠ\n\n"
global.prefa = ['','!','.','#','&']  
global.sessionName = 'session' // Jangan Ubah
global.tekspushkon = ''
global.keyopenai ='iigf'

// BOT SETTINGS
global.autobio = true
global.wlcm = true
global.autoclsession = true
global.anticall = false
global.autoreactsw = false

//media target
global.thumb = { url: 'https://files.catbox.moe/tuqow6.jpg' }//ur thumb pic
global.defaultpp = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60' //default pp wa

//messages
global.mess = {
selesai: 'ᴅᴏɴᴇ ᴘʀᴏᴄᴄᴇꜱꜱ ☑️', 
owner: '*[ ACCES DENIED ]*\nFeature Acces Owner Only !',
private: '*[ ACCES DENIED ]*\nFeature Acces Private Only !',
group: '*[ ACCES DENIED ]*\nFeature Acces Group Only !',
wait: '*[ MESSAGE WAITING ]*\n_Please Wait Prosessing..._',
access: '*[ ACCES DENIED ]*\nYou Do Not Have Access To This Feature !',
admin: '*[ ACCES DENIED ]*\nThe Bot Must Be An Admin First !',    
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update'${__filename}'`))
delete require.cache[file]
require(file)
})
